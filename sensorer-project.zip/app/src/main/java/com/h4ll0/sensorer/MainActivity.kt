package com.h4ll0.sensorer

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

private val Red = Color(0xFFE0262E)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Red, background = Color(0xFF0D0A0A), surface = Color(0xFF191212))) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) { App() }
            }
        }
    }

    fun hasOverlay() = Settings.canDrawOverlays(this)

    fun start() {
        val i = Intent(this, OverlayService::class.java)
        if (Build.VERSION.SDK_INT >= 26) ContextCompat.startForegroundService(this, i) else startService(i)
    }
    fun stop() = stopService(Intent(this, OverlayService::class.java))
}

@Composable
fun App() {
    val a = androidx.compose.ui.platform.LocalContext.current as MainActivity
    var granted by remember { mutableStateOf(a.hasOverlay()) }
    var running by remember { mutableStateOf(false) }
    val launcher = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()
    ) { granted = a.hasOverlay() }

    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
        Text("Auto Sensorer", fontSize = 32.sp, fontWeight = FontWeight.Bold, color = Red)
        Spacer(Modifier.height(6.dp))
        Text("Bubble melayang + kotak sensor manual di atas app apa pun. App ini juga anti-screenshot / anti-rekam.", color = Color.Gray)
        Spacer(Modifier.height(24.dp))

        if (!granted) {
            Text("1. Izinkan \"Tampil di atas app lain\" dulu:", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Button({
                launcher.launch(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${a.packageName}")))
            }) { Text("Buka pengaturan izin") }
        } else {
            Text("Izin overlay: aktif ✓", color = Color(0xFF7CFF8C))
            Spacer(Modifier.height(16.dp))
            if (!running) {
                Button({ a.start(); running = true }, Modifier.fillMaxWidth()) { Text("Nyalakan bubble") }
            } else {
                OutlinedButton({ a.stop(); running = false }, Modifier.fillMaxWidth()) { Text("Matikan bubble") }
                Spacer(Modifier.height(12.dp))
                Text("Cara pakai:\n1. Tap bubble merah buat munculin kotak hitam.\n2. Geser kotak buat pindah, geser sudut kanan-bawah buat besarin.\n3. Tap bubble lagi buat sembunyikan kotak.", color = Color.Gray)
            }
        }
    }
}
