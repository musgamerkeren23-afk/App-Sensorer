package com.h4ll0.sensorer

import android.app.*
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import androidx.core.app.NotificationCompat
import kotlin.math.max

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: View? = null
    private var box: FrameLayout? = null
    private var boxParams: WindowManager.LayoutParams? = null
    private var boxShown = false

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        startForeground(1, notif())
        addBubble()
    }

    private fun notif(): Notification {
        val ch = "sensorer"
        if (Build.VERSION.SDK_INT >= 26) {
            val c = NotificationChannel(ch, "Auto Sensorer", NotificationManager.IMPORTANCE_MIN)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(c)
        }
        return NotificationCompat.Builder(this, ch)
            .setContentTitle("Auto Sensorer aktif")
            .setContentText("Tap bubble merah buat munculin/sembunyiin kotak sensor")
            .setSmallIcon(android.R.drawable.ic_secure)
            .setOngoing(true).build()
    }

    private fun overlayType() =
        if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    private fun addBubble() {
        val b = View(this).apply {
            setBackgroundColor(Color.parseColor("#E0262E"))
            alpha = 0.95f
        }
        val size = (52 * resources.displayMetrics.density).toInt()
        val p = WindowManager.LayoutParams(
            size, size, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        p.gravity = Gravity.TOP or Gravity.START
        p.x = 20; p.y = 200
        var dx = 0f; var dy = 0f; var sx = 0; var sy = 0; var moved = false
        b.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; sx = p.x; sy = p.y; moved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    p.x = sx + (e.rawX - dx).toInt(); p.y = sy + (e.rawY - dy).toInt()
                    if (max(kotlin.math.abs(e.rawX - dx), kotlin.math.abs(e.rawY - dy)) > 12) moved = true
                    wm.updateViewLayout(b, p); true
                }
                MotionEvent.ACTION_UP -> { if (!moved) toggleBox(); true }
                else -> false
            }
        }
        wm.addView(b, p)
        bubble = b
    }

    private fun toggleBox() {
        if (boxShown) { box?.let { wm.removeView(it) }; boxShown = false; return }
        val f = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        val handle = View(this).apply { setBackgroundColor(Color.parseColor("#AAE0262E")) }
        val hs = (28 * resources.displayMetrics.density).toInt()
        f.addView(handle, FrameLayout.LayoutParams(hs, hs, Gravity.BOTTOM or Gravity.END))

        val p = WindowManager.LayoutParams(
            (200 * resources.displayMetrics.density).toInt(),
            (120 * resources.displayMetrics.density).toInt(),
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.OPAQUE
        )
        p.gravity = Gravity.TOP or Gravity.START
        p.x = 100; p.y = 400

        var dx = 0f; var dy = 0f; var sx = 0; var sy = 0
        f.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; sx = p.x; sy = p.y; true }
                MotionEvent.ACTION_MOVE -> {
                    p.x = sx + (e.rawX - dx).toInt(); p.y = sy + (e.rawY - dy).toInt()
                    wm.updateViewLayout(f, p); true
                }
                else -> false
            }
        }
        var rdx = 0f; var rdy = 0f; var rw = 0; var rh = 0
        handle.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { rdx = e.rawX; rdy = e.rawY; rw = p.width; rh = p.height; true }
                MotionEvent.ACTION_MOVE -> {
                    p.width = max(80, rw + (e.rawX - rdx).toInt())
                    p.height = max(60, rh + (e.rawY - rdy).toInt())
                    wm.updateViewLayout(f, p); true
                }
                else -> false
            }
        }
        wm.addView(f, p)
        box = f; boxParams = p; boxShown = true
    }

    override fun onDestroy() {
        super.onDestroy()
        bubble?.let { runCatching { wm.removeView(it) } }
        box?.let { runCatching { wm.removeView(it) } }
    }
}
